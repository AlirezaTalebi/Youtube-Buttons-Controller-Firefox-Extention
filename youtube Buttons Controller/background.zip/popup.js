document.getElementById('nextButton').addEventListener('click', () => {
  browser.tabs.query({ url: "*://*.youtube.com/*" })
    .then((tabs) => {
      browser.tabs.sendMessage(tabs[0].id, { command: 'clickNextButton' });
    })
    .catch((error) => {
      console.error('Error querying active tab:', error);
    });
});

document.getElementById('stopButton').addEventListener('click', () => {
  browser.tabs.query({ url: "*://*.youtube.com/*" })
    .then((tabs) => {
      browser.tabs.sendMessage(tabs[0].id, { command: 'clickStopButton' });
    })
    .catch((error) => {
      console.error('Error querying active tab:', error);
    });
});

document.getElementById('backButton').addEventListener('click', () => {
  browser.tabs.query({ url: "*://*.youtube.com/*" })
    .then((tabs) => {
      browser.tabs.executeScript(tabs[0].id, { code: 'history.back();' });
    })
    .catch((error) => {
      console.error('Error querying active tab:', error);
    });
});
document.getElementById('popupButton').addEventListener('click', () => {
  browser.tabs.query({ url: "*://*.youtube.com/*" })
    .then((tabs) => {
      browser.tabs.sendMessage(tabs[0].id, { command: 'clickpopupButton' });
    })
    .catch((error) => {
      console.error('Error querying active tab:', error);
    });
});
