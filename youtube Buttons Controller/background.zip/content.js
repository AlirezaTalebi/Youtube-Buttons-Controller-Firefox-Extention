async function nextButton() {
  let tabId = parseInt(localStorage.getItem("abcd"));  // Convert to integer if needed
  let tab = await browser.tabs.get(tabId);
  if (tab) {
    browser.tabs.executeScript(tabId, {
      code: 'document.querySelector(".ytp-next-button").click();'
    });
  }
}

async function stopButton() {
  let tabId = parseInt(localStorage.getItem("abcd"));  // Convert to integer if needed
  let tab = await browser.tabs.get(tabId);
  if (tab) {
    browser.tabs.executeScript(tabId, {
      code: 'document.querySelector(".ytp-play-button").click();'
    });
  }
}

async function muteButton() {
  let tabId = parseInt(localStorage.getItem("abcd"));  // Convert to integer if needed
  let tab = await browser.tabs.get(tabId);
  if (tab) {
    browser.tabs.executeScript(tabId, {
      code: 'document.querySelector(".ytp-mute-button").click();'
    });
  }
}

async function backButton() {
  let tabId = parseInt(localStorage.getItem("abcd"));  // Convert to integer if needed
  let tab = await browser.tabs.get(tabId);
  if (tab) {
    browser.tabs.executeScript(tabId, {
      code: 'history.back();'
    });
  }
}

async function getTab() {
  let queryOptions = { active: true, currentWindow: true };
  let [tab] = await browser.tabs.query(queryOptions);
  if (tab) {
    localStorage.setItem("abcd", tab.id);
  }
}

document.getElementById('nextButton').addEventListener("click", nextButton);
document.getElementById('stopButton').addEventListener("click", stopButton);
document.getElementById('backButton').addEventListener("click", backButton);
document.getElementById('muteButton').addEventListener("click", muteButton);
document.getElementById('getTabButton').addEventListener("click", getTab);
